import re, random, math, secrets, os, datetime

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User

from .myforms import RegisterForm, LoginForm, TransactionForm
from .jsfunctions import *
from query_calls import *
from validation import *
from ocr import ocr_execute


# Landing page of the website
# TODO: if sessionID in cookies: auto-login
def index(request):
    return render(request, "index.html")


# Register page
# TODO: if sessionID in cookies: auto-login
def register(request):
    # Only go here if it is a POST instead of a GET
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        print(request.POST.get('gender'))
        if request.POST.get('terms') is None:
            print("Yoy")
            return render(request, 'register.html', {'terms_error': "Please accept terms and conditions."})
        # Check for validity of form data
        if form.is_valid():
            user_error = ""
            email_error = ""
            username = form.cleaned_data["username"]
            email = form.cleaned_data["email"]
            if (username,) in get_all_given("profiles", "username"):
                return render(request, "register.html", {'user_error': "Username already exists"})
            elif (email,) in get_all_given("profiles", "email"):
                return render(request, "register.html", {'email_error': "email already exists"})
            else:
                username = form.cleaned_data["username"]
                email = form.cleaned_data["email"]
                password = form.cleaned_data["password"]
                name = "TEMP ORARY"
                gender = request.POST.get('gender')
                dob = format_date(form.cleaned_data["dob"], False, True)
                user = User.objects.create_user(username, email, password)
                user.save()
                validate(email)
                add_new_profile(username, name, gender, dob, email, "We don't store passwords in plaintext")
                return render(request, "confirmregister.html")
        else:

            # Sort error data to display
            user_error = ""
            email_error = ""
            password_error = ""
            dob_error = ""
            # Check if errors appear in the form
            if "username" in form.errors:
                user_error = form.errors["username"]
            if "email" in form.errors:
                email_error = form.errors["email"]
            if "password" in form.errors:
                password_error = form.errors["password"]
                if form.non_field_errors():
                    password_error.append(form.non_field_errors())
            if not password_error:
                if form.non_field_errors():
                    password_error = form.non_field_errors()
            if "dob" in form.errors:
                dob_error = form.errors["dob"]
            return render(request, "register.html", {'user_error': user_error,
                                                     'email_error': email_error, 'password_error': password_error,
                                                     'dob_error': dob_error})
    else:
        return render(request, "register.html")


def overview_graph(request):

    username = request.user.username
    # Get user information
    pid, _, name, _, _, _, _, _ = get_where("profiles", "*", "username='" + username + "'")[0]

    transactions = object_query_sorted(Transaction, Transaction.profile_id == pid, Transaction.date_time)
    transactions.reverse()

    past_months = get_prev_months()
    tmp = {}
    for i in past_months:
        tmp[i] = 0

    for transaction in transactions:
        d = transaction.date_time.day
        m = transaction.date_time.month
        y = transaction.date_time.year

        if (m, y) in tmp and transaction.inc_exp == 'E':
            tmp[(m, y)] += transaction.amount
    return tmp

def get_prev_months():
    day = datetime.datetime.now().day
    month = datetime.datetime.now().month
    curr_year = datetime.datetime.now().year

    if month >= 6:
        return reversed([(month, curr_year), (month - 1, curr_year), (month - 2, curr_year), (month - 3, curr_year),
                (month - 4, curr_year), (month - 5, curr_year)])
    else:
        to_return = []
        curr_month = month
        for i in range(0, 6):
            to_return.append((curr_month, curr_year))
            if curr_month == 1:
                curr_year -= 1
                curr_month = 12
            else:
                curr_month -= 1
        return reversed(to_return)

# Features Page
# TODO: if sessionID in cookies: auto-login
def features(request):
    return render(request, "features.html")


# Test pages to test out new functions and such
def test(request):
    tmp = get_all_given("profiles", "username")
    if ("latishahiedi86",) in tmp:
        print("I'M IN HERE")
    print(secrets.token_urlsafe(10))
    if (request.GET.get('del')):
        for users in User.objects.all():
            if (users.username != "admin"):
                users.delete()
    if (request.GET.get('repop')):
        for profile in get_all_given("profiles", "*"):
            _, usr, _, _, _, eml, pss, _ = profile
            user = User.objects.create_user(usr, eml, pss)
            user.save()
    names = []
    for users in User.objects.all():
        names.append(users.username)

    return render(request, "test.html", {'a': 4, 'b': 20, 'c': 0, 'd': 11,
                                         'label1': "PASSED", 'label2': "NICE", 'spend': limit_graph(), 'names': names})


# Basic overview page for dashboard
@login_required
def overview(request):

    curr_day = datetime.datetime.now().day
    curr_month = datetime.datetime.now().month
    curr_year = datetime.datetime.now().year
    username = request.user.username
    print(username)
    # Get user information
    pid, _, name, _, _, _, _, _ = get_where("profiles", "*", "username='" + username + "'")[0]
    # Get transactions
    if request.method == 'POST':
        form = TransactionForm(request.POST)
        got_date = request.POST.get('date')
        date_time = datetime.datetime.strptime(got_date, "%b %d, %Y")

        if request.POST.get('money_expense'):
            amount = request.POST.get('money_expense')
            inc_exp = "E"  # TEMP - support expense tab only
            trans_type_num = request.POST.get('expense_type')

            trans_types = ['0', 'Food/Drinks', 'Bills', 'Electronics', 'Entertainment', 'Travel', 'Debt', 'Clothing',
                       'Automobile', 'Pets', 'E', 'Other/Expenses']
            transaction_type = trans_types[int(trans_type_num)]
            add_new_transaction(pid, date_time, amount, None, inc_exp, transaction_type)
        else:
            amount = request.POST.get('money_income')
            inc_exp = "I"  # TEMP - support expense tab only
            trans_type_num = request.POST.get('income_type')

            trans_types = ['0', 'Salary', 'Investments', 'Other/Income']
            transaction_type = trans_types[int(trans_type_num)]
            add_new_transaction(pid, date_time, amount, None, inc_exp, transaction_type)

    transactions = object_query_sorted(Transaction, Transaction.profile_id == pid, Transaction.date_time)
    transactions.reverse()

    odometer_daily = 0
    odometer_expense_monthly = 0
    odometer_income_monthly = 0
    for transaction in transactions:
        d = transaction.date_time.day
        m = transaction.date_time.month
        y = transaction.date_time.year
        if (m == curr_month) and (y == curr_year):
            if transaction.inc_exp == 'E':
                odometer_expense_monthly += transaction.amount
                if d == curr_day:
                    odometer_daily += transaction.amount
            else:
                odometer_income_monthly += transaction.amount
    tmp = overview_graph(request)
    print(tmp)
    response = render(request, "overview.html", {'overview': test_overview_graph(tmp), 'full_name': name,
                                             'odometer': overview_odometer(round(odometer_daily, 1), round(odometer_expense_monthly, 1), round(odometer_income_monthly, 1)),
                                             'transaction_list': transactions[:5], 'page_name' : 'Overview'})

    if request.COOKIES.get("helper"):
        response.set_cookie("helper", "b")
    else:
        response.set_cookie('helper', "a")
    return response

@login_required
def transactions(request):
    username = request.user.username
    pid, _, name, _, _, _, _, _ = get_where("profiles", "*", "username='" + username + "'")[0]
    print(request.path)
    if request.method == 'POST':
        ### only considers expense tab for now ###
        print("***** DEBUG: posting transaction *****")
        form = TransactionForm(request.POST)


        if request.POST.get('money_expense'):
            got_date = request.POST.get('date_expense')
            print(got_date)
            date_time = datetime.datetime.strptime(got_date, "%b %d, %Y")
            amount = request.POST.get('money_expense')
            comment = request.POST.get("comment_expense")
            inc_exp = "E"

            trans_type_num = request.POST.get('expense_type')

            trans_types = ['0', 'Food/Drinks', 'Bills', 'Electronics', 'Entertainment', 'Travel', 'Debt', 'Clothing',
                       'Health', 'Automobile', 'Pets', 'Other/Expenses']
            transaction_type = trans_types[int(trans_type_num)]
            print("**********")
            add_new_transaction(pid, date_time, amount, comment, inc_exp, transaction_type)

        else:
            got_date = request.POST.get('date_income')
            print(got_date)
            date_time = datetime.datetime.strptime(got_date, "%b %d, %Y")
            amount = request.POST.get('money_income')
            comment = request.POST.get("comment_income")
            inc_exp = "I"

            trans_type_num = request.POST.get('income_type')

            trans_types = ['0', 'Salary', 'Investments', 'Other/Income']
            transaction_type = trans_types[int(trans_type_num)]

            print("**********")
            add_new_transaction(pid, date_time, amount, comment, inc_exp, transaction_type)
        # return redirect(request.path)
        return redirect(request.POST.get('curr_path').lower())

    else:
        return render(request, "transactions.html", {'full_name': name, 'page_name' : 'Transactions'})

@login_required
def recurring(request):
    username = request.user.username
    pid, _, name, _, _, _, _, _ = get_where("profiles", "*", "username='" + username + "'")[0]

    # transactions = get_recurring_transactions(pid)
    transactions = object_query(Recurring_transaction, Recurring_transaction.profile_id == pid, "all")
    messages = object_query(Message, Message.id == pid, "all")
    print(messages)
    return render(request, "recurring.html", {'full_name': name, 'page_name' : 'Recurring', 'transaction_list' : transactions, 'messages' : messages})

@login_required
def budget(request):
    username = request.user.username
    pid, _, name, _, _, _, _, _ = get_where("profiles", "*", "username='" + username + "'")[0]
    limits = object_query_sorted(Limit, Limit.profile_id == pid, Limit.amount)
    trans_types = ['Food/Drinks', 'Bills', 'Electronics', 'Entertainment', 'Travel', 'Debt', 'Clothing',
               'Health', 'Automobile', 'Pets', 'Other/Expenses']
    for i in limits:
        if i.type in trans_types:
            trans_types.remove(i.type)
    no_limit = []
    for i in trans_types:
        tmp = {}
        tmp[i] = 0
        no_limit.append(tmp)
    return render(request, "budget.html", {'full_name': name, 'page_name' : 'Budget', 'limits' : limits, 'no_limit' : no_limit})


@login_required
def expenses(request):
    username = request.user.username
    pid, _, name, _, _, _, _, _ = get_where("profiles", "*", "username='" + username + "'")[0]

    return render(request, "expenses.html", {'full_name': name, 'page_name' : 'Expenses'})


@login_required
def savings(request):
    username = request.user.username
    pid, _, name, _, _, _, _, _ = get_where("profiles", "*", "username='" + username + "'")[0]

    return render(request, "savings.html", {'full_name': name, 'page_name' : 'Savings'})


@login_required
def settings(request):
    username = request.user.username
    pid, _, name, _, _, email, _, _ = get_where("profiles", "*", "username='" + username + "'")[0]

    # if request.method == "POST":
    #     f = request.FILES['profile_img']
    #     #SANITISE
    #
    #     print(f)
    #     with open('sample_receipts/new_img.png', 'wb+') as destination:
    #         for chunk in f.chunks():
    #             destination.write(chunk)
    #
    #     return render(request, "settings.html", {'full_name': name, 'email': email, 'page_name': 'Settings'})
    # else:
    return render(request, "settings.html", {'full_name': name, 'email': email, 'page_name' : 'Settings'})


@login_required
def history(request):
    username = request.user.username
    pid, _, name, _, _, _, _, _ = get_where("profiles", "*", "username='" + username + "'")[0]
    transactions = object_query_sorted(Transaction, Transaction.profile_id == pid, Transaction.date_time)
    transactions.reverse()

    if (request.GET.get('category')):
        t_income = {}
        t_expense = {}
        for transaction in transactions:
            if transaction.inc_exp == "E":
                if transaction.type not in t_expense:
                    t_expense[transaction.type] = []
                else:
                    t_expense[transaction.type].append(transaction)
            else:
                if transaction.type not in t_income:
                    t_income[transaction.type] = []
                else:
                    t_income[transaction.type].append(transaction)

        sum_income = {}
        sum_expense = {}
        for key, value in t_income.items():
            if key == "Other/Income":
                sum_income["Other"] = 0
            sum_income[key] = 0

        for key, value in t_expense.items():
            if key == "Other/Expenses":
                sum_expense["Other"] = 0
            if key == "Food/Drinks":
                sum_expense["Food"] = 0
            sum_expense[key] = 0

        for key, value in t_income.items():
            for value1 in value:
                if key == "Other/Income":
                    sum_income["Other"] += int(value1.amount)
                sum_income[key] += int(value1.amount)

        for key, value in t_expense.items():
            for value1 in value:
                if key == "Other/Expenses":
                    sum_expense["Other"] += int(value1.amount)
                if key == "Food/Drinks":
                    sum_expense["Food"] += int(value1.amount)
                sum_expense[key] += int(value1.amount)

        return render(request, "categorized.html",
                      {'full_name': name, 'catincome': t_income, 'catexpense': t_expense, 'sum_income': sum_income,
                       'sum_expense': sum_expense, 'page_name' : 'History'})

    else:
        # Pagination stuff
        curr = 1;
        pages = [1, 2, 3, 4, 5]
        # If previous get request, get previous page
        if (request.GET.get('prev') and int(request.GET.get('prev')) > 0):
            curr = int(request.GET.get('prev'))

        # If next, get next page
        if (request.GET.get('next')):
            curr = int(request.GET.get('next'))
        # If specific page request
        if (request.GET.get('page')):
            curr = int(request.GET.get('page'))
            if curr < 1:
                curr = 1

        if curr > math.ceil(len(transactions) / 10):
            curr = math.ceil(len(transactions) / 10)
        # Handle displaying of pages
        if len(transactions) <= 40:
            pages = list(range(1, math.ceil(len(transactions) / 10)))
        elif (curr > 3 and (curr + 2) * 10 <= math.ceil(len(transactions) / 10) * 10):
            pages = [curr - 2, curr - 1, curr, curr + 1, curr + 2]
        elif (curr > 3 and (curr + 1) * 10 <= math.ceil(len(transactions) / 10) * 10):
            pages = [curr - 3, curr - 2, curr - 1, curr, curr + 1]
        elif (curr > 3 and (curr) * 10 <= math.ceil(len(transactions) / 10) * 10):
            pages = [curr - 4, curr - 3, curr - 2, curr - 1, curr]
        # Display page number * 10 to display data from that page
        max_disp = int(curr) * 10
        # Prevent out of bounds errors
        if max_disp > len(transactions):
            max_disp = len(transactions)
        # Mininum display amount
        min_disp = max_disp - 10
        if min_disp < 0:
            min_disp = 0
        print(pages)
        return render(request, "history.html",
                      {'full_name': name, 'transaction_list': transactions[min_disp:max_disp], 'curr': curr, 'pages': pages, 'page_name' : 'History'})

@login_required
def edit_transaction(request):
    username = request.user.username
    pid, _, name, _, _, _, _, _ = get_where("profiles", "*", "username='" + username + "'")[0]

    if request.method == "POST":
        print("Received from form...")
        t_id = request.POST.get("transaction_id")
        print("Transaction ID = " + str(t_id))

        ie = request.POST.get("money_type")
        print("income/expense = " + str(ie))

        new_money = request.POST.get("money")
        print("Money = " + str(new_money))
        new_time = request.POST.get("time")

        print("Time = " + str(new_time))
        new_date = request.POST.get("date")
        print("Date = " + str(new_date))
        date_time = datetime.datetime.strptime(new_date + " " + new_time, "%b %d, %Y %H:%M")

        category_num = int(request.POST.get("transaction_type"))
        trans_types = ['0', 'Food/Drinks', 'Bills', 'Electronics', 'Entertainment', 'Travel', 'Debt', 'Clothing',
                       'Health', 'Automobile', 'Pets', 'Other/Expenses']
        if ie == "I":
            trans_types = ['0', 'Salary', 'Investments', 'Other/Income']
        new_category = trans_types[category_num]
        print("Category = " + str(new_category))
        new_comment = request.POST.get("comment")
        print("Comment = " + str(new_comment))

        #edit transaction
        edit_existing_transaction(pid, t_id, date_time, new_money, new_comment, ie, new_category)  # don't specify category, I/E for now

        print("Redirecting to history...")
        return redirect('history')
    else:
        return redirect('index')

@login_required
def receipt_upload(request):
    if request.method == "POST":
        f = request.FILES['profile_img']
        # SANITISE

        print(f)
        with open('sample_receipts/new_img.jpg', 'wb+') as destination:
            for chunk in f.chunks():
                destination.write(chunk)

        result = ocr_execute("sample_receipts/new_img.jpg")
        print(result)

        return redirect('overview')

    else:
        return redirect('index')

def download(request):
    return render(request, "download.html")

def credits(request):
    return render(request, "credits.html")

# Takes a YYYYMMDD date string and formats
# it to either DDMMYYYY or DD/MM/YYYY
def format_date(date, slash=False, reverse=False):
    if slash:
        return str(date[6:8]) + "/" + str(date[4:6]) + "/" + str(date[0:4])
    else:
        if reverse:
            return str(date[6:10]) + str(date[3:5]) + str(date[0:2])
        return str(date[6:8]) + str(date[4:6]) + str(date[0:4])

    # Takes a list of tuples containing transaction information


# and turns it into html code
# TODO: Format better.
def transactions_html(transactions):
    htmlified = []
    for transaction in transactions:
        _, _, date, time, amnt, comment, duh, stype = transaction
        # Add slashes to the date
        formatted_date = format_date(date, True)
        html = "<a href='#!' class='collection-item'>" + \
               "<div class=row>" + \
               "<div class = 'grey-text text-darken-2 col s6 left-align' style='font-size: 22px; padding-top: 0;'>" + "$" + str(
            amnt) + "</div>" + \
               "<div class = 'col s6 right-align'>" + \
               str(time) + "  " + formatted_date + "</div></div></a>"
        htmlified.append(html)
    return htmlified


# TESTING ONLY
# Graph display total spent this month out of limit
def limit_graph():
    types = ["'spent'", "'not spent'"]
    expenses = [random.randint(0, 255), random.randint(0, 255)]
    colours = "['rgba(127,255,0,1)','rgba(0,0,0,0)',]"
    return donut_graph_no_label("spend", types, expenses, colours)


# TESTING ONLY
# Simple test for graph
def test_graph():
    types = ["'food'", "'entertainment'", "'travel'", "'bills'", "'pets'"]
    expenses = [random.randint(0, 255), random.randint(0, 255), random.randint(0, 255),
                random.randint(0, 255), random.randint(0, 255)]
    colours = generate_colours(len(types))
    return donut_graph_no_label("expense", types, expenses, colours)


# TESTING ONLY
# Display spending of past 6 monthss.
def test_overview_graph(past):
    name = "overview6"
    title = "'Monthly spending past 6 months'"
    labels = []
    data = []
    for key, val in past.items():
        m, y = key
        labels.append(int_to_month(m))
        data.append(str(val))
        print(val)
    #labels = ["'Jan'", "'Feb'", "'Mar'", "'Apr'", "'May'", "'Jun'"]
    #data = "[1234, 434, 3456, 1337, 5678, 6789]"
    return bar_graph_monthly(name, title, labels, data)

def int_to_month(num):
    if num == 1:
        return "Jan"
    elif num == 2:
        return "Feb"
    elif num == 3:
        return "Mar"
    elif num == 4:
        return "Apr"
    elif num == 5:
        return "May"
    elif num == 6:
        return "Jun"
    elif num == 7:
        return "Jul"
    elif num == 8:
        return "Aug"
    elif num == 9:
        return "Sep"
    elif num == 10:
        return "Oct"
    elif num == 11:
        return "Nov"
    else:
        return "Dec"
# Generates a random colour then makes
# shades of that colour
def generate_colours(length):
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    factor = 0.65

    init = "["
    for i in range(0, length):
        r = math.floor(r * factor)
        g = math.floor(g * factor)
        b = math.floor(b * factor)
        init += "'rgba(" + str(r) + "," + str(g) + "," + str(b) + ", 1)',"
    init += "]"
    return init
