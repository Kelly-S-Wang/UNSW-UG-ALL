from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('register/', views.register, name = 'register'),
    path('features/', views.features, name = 'features'),
    path('registerconfirm/', views.register, name = 'registerconfirm'),
    path('test/', views.test, name = 'test'),
    path('overview/', views.overview, name = 'overview'),
    path('transactions/', views.transactions, name = 'transactions'),
    path('budget/', views.budget, name = 'budget'),
    path('history/', views.history, name = 'history'),
    path('expenses/', views.expenses, name = 'expenses'),
    path('savings/', views.savings, name = 'savings'),
    path('settings/', views.settings, name = 'settings'),
    path('edittransaction/', views.edit_transaction, name='edit_transaction'),
    path('recurring/', views.recurring, name='recurring'),
    path('download/', views.download, name='download'),
    path('credits/', views.credits, name='credits'),
    path('receiptupload/', views.receipt_upload, name='receipt_upload')
]