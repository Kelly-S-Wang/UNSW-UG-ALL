(function($){
  $(function(){

    $('.collapsible').collapsible();
    $('.parallax').parallax();

  }); // end of document ready
})(jQuery); // end of jQuery name space
