setTimeout(function(){
    daily_spend.innerHTML = 501;
    monthly_spend.innerHTML = 4252;
}, 1000);